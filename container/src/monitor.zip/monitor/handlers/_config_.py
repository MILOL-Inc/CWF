PORT = '9090'
COOKIE_SECRET = '9ct!1ntF3rbgVSvus@dw)PKwv&E$JomO'