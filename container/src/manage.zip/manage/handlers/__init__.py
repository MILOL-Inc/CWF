from handlers import IndexHandler
from handlers import DefaultHandler
from handlers import TermsHandler
from handlers import AuthHandler